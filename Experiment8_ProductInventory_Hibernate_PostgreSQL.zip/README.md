# Experiment 8 — Product Inventory (Maven + Hibernate + PostgreSQL)

Implements Add, View, Update, and Delete product operations using Hibernate ORM and PostgreSQL.

## Setup
1. Install JDK 17+, Maven, and PostgreSQL.
2. In PostgreSQL create database: `CREATE DATABASE inventorydb;`
3. Edit `src/main/resources/hibernate.cfg.xml`; replace `CHANGE_ME` with your PostgreSQL password (and username if needed).
4. Run from project root: `mvn compile exec:java -Dexec.mainClass=com.inventory.MainProgram`
   (If the exec plugin is not configured, run `mvn package`, then run `com.inventory.MainProgram` from your IDE.)
5. Hibernate creates/updates the `product` table automatically.

## GitHub
Do not commit your real database password. Replace it with a placeholder before pushing.
