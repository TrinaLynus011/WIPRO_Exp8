package com.inventory;
import java.util.Scanner;
public class MainProgram {
 public static void main(String[] args){Scanner sc=new Scanner(System.in);ProductDAO dao=new ProductDAO();
  while(true){System.out.println("\\n===== PRODUCT INVENTORY =====\\n1. Add Product\\n2. View Products\\n3. Update Product\\n4. Delete Product\\n5. Exit");System.out.print("Enter your choice: ");
   int choice=sc.nextInt();switch(choice){
    case 1:sc.nextLine();System.out.print("Product name: ");String name=sc.nextLine();System.out.print("Category: ");String cat=sc.nextLine();System.out.print("Price: ");double price=sc.nextDouble();System.out.print("Quantity: ");int qty=sc.nextInt();dao.addProduct(new Product(name,cat,price,qty));break;
    case 2:dao.viewProducts();break;
    case 3:System.out.print("Product ID: ");int id=sc.nextInt();System.out.print("New price: ");double np=sc.nextDouble();System.out.print("New quantity: ");int nq=sc.nextInt();dao.updateProduct(id,np,nq);break;
    case 4:System.out.print("Product ID: ");dao.deleteProduct(sc.nextInt());break;
    case 5:sc.close();HibernateUtil.getSessionFactory().close();System.out.println("Program terminated.");return;
    default:System.out.println("Invalid choice.");
   }
  }
 }
}
