package com.inventory;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
public class ProductDAO {
 public void addProduct(Product p){Transaction tx=null;try(Session s=HibernateUtil.getSessionFactory().openSession()){tx=s.beginTransaction();s.persist(p);tx.commit();System.out.println("Product added successfully.");}catch(Exception e){if(tx!=null)tx.rollback();e.printStackTrace();}}
 public void viewProducts(){try(Session s=HibernateUtil.getSessionFactory().openSession()){List<Product> list=s.createQuery("from Product",Product.class).list();System.out.println("\\n--- Product Inventory ---");list.forEach(System.out::println);}}
 public void updateProduct(int id,double price,int quantity){Transaction tx=null;try(Session s=HibernateUtil.getSessionFactory().openSession()){tx=s.beginTransaction();Product p=s.get(Product.class,id);if(p!=null){p.setPrice(price);p.setQuantity(quantity);System.out.println("Product updated.");}else System.out.println("Product not found.");tx.commit();}catch(Exception e){if(tx!=null)tx.rollback();e.printStackTrace();}}
 public void deleteProduct(int id){Transaction tx=null;try(Session s=HibernateUtil.getSessionFactory().openSession()){tx=s.beginTransaction();Product p=s.get(Product.class,id);if(p!=null){s.remove(p);System.out.println("Product deleted.");}else System.out.println("Product not found.");tx.commit();}catch(Exception e){if(tx!=null)tx.rollback();e.printStackTrace();}}
}
