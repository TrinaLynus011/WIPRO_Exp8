package com.inventory;
import jakarta.persistence.*;
@Entity @Table(name="product")
public class Product {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private int id;
 private String name; private String category; private double price; private int quantity;
 public Product(){}
 public Product(String name,String category,double price,int quantity){this.name=name;this.category=category;this.price=price;this.quantity=quantity;}
 public int getId(){return id;} public String getName(){return name;} public void setName(String v){name=v;}
 public String getCategory(){return category;} public void setCategory(String v){category=v;}
 public double getPrice(){return price;} public void setPrice(double v){price=v;}
 public int getQuantity(){return quantity;} public void setQuantity(int v){quantity=v;}
 @Override public String toString(){return "ID: "+id+", Name: "+name+", Category: "+category+", Price: "+price+", Quantity: "+quantity;}
}
